# Detecting Spearphishing Attacks in Corporate Networks

Introduction to Threat Hunting · Danial Rahman · CS-2421

## Week 4 increment

Analyze the RSA 2011 attack using the Cyber Kill Chain and map its stages to MITRE ATT&CK. The report labels reported behavior, inference and general malware capabilities separately.

- [Week 4 report](docs/week4_report.md)
- [Defense script](docs/defense.md)
- [Attack diagram](images/kill_chain.png)
- [Recorded demonstration output](docs/demo_output.txt)
- [Synthetic events](data/synthetic_events.csv)
- [Python analysis](scripts/analyze_events.py)

## Run the demonstration

Requires Python 3. No third party dependencies or network access are needed.

```bash
python3 scripts/analyze_events.py
```

Expected result: DEMO-PC-01 is flagged, with one host requiring review. All input records are synthetic. The script does not execute malware or contact the listed addresses.

## Add to GitHub

Copy these files into the intended repository, preserving the folder structure. Review the files and run the demonstration. From that repository folder:

```bash
git add README.md docs data scripts images
git commit -m "Week 4: add RSA Kill Chain analysis and synthetic log demonstration"
git push
```

If this is a new repository, create it in your GitHub account, clone it and then copy the files into the clone before running the commands. Commands assume a configured remote and branch.

Commit later changes when they occur. Use `git log --oneline` on the real repository to show progress during the defense. This package does not include a fabricated commit history or claim earlier weekly work.

Suggested next changes: collect authorized lab telemetry, improve event correlation and evaluate benign examples. Other group members can add their names to the report after reviewing their contribution.
